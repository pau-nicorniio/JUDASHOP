# JUDASHOP

Marketplace móvil de compra y venta, preparado para Expo + Supabase + EAS.

## Primer arranque
1. Copia `.env.example` a `.env`.
2. Pon la URL y la Publishable Key de tu proyecto Supabase JUDASHOP.
3. Instala dependencias con `npx expo install`.
4. Arranca con `npx expo start`.

La app ya contiene la estructura visual inicial de JUDASHOP y pantallas de Inicio, Buscar, Vender, Mensajes y Perfil.

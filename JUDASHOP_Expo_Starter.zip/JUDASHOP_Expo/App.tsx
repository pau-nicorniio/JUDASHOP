import React, { useEffect, useState } from 'react'
import {
  Alert, Image, Pressable, SafeAreaView, ScrollView, StyleSheet,
  Text, TextInput, View, useWindowDimensions
} from 'react-native'
import * as ImagePicker from 'expo-image-picker'
import { StatusBar } from 'expo-status-bar'
import { supabase } from './lib/supabase'

const PINK = '#ff3f8f'
const BG = '#fff8fb'
const dark = '#202024'

const demoProducts = [
  { id: '1', title: 'Nike Air Max', price: '49,00 €', cat: 'Zapatillas', img: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=800' },
  { id: '2', title: 'Bolso rosa', price: '28,00 €', cat: 'Bolsos', img: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=800' },
  { id: '3', title: 'Sudadera oversize', price: '22,00 €', cat: 'Ropa', img: 'https://images.unsplash.com/photo-1551488831-00ddcb6c6bd3?w=800' },
  { id: '4', title: 'Cámara compacta', price: '75,00 €', cat: 'Tecnología', img: 'https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=800' }
]

export default function App() {
  const [tab, setTab] = useState('Inicio')
  const [search, setSearch] = useState('')
  const [picked, setPicked] = useState<string[]>([])
  const [session, setSession] = useState<any>(null)

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setSession(data.session))
    const { data: listener } = supabase.auth.onAuthStateChange((_event, next) => setSession(next))
    return () => listener.subscription.unsubscribe()
  }, [])

  const filtered = demoProducts.filter(p =>
    (p.title + p.cat).toLowerCase().includes(search.toLowerCase())
  )

  async function pickImages() {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ['images'],
      allowsMultipleSelection: true,
      selectionLimit: 8,
      quality: 0.85
    })
    if (!result.canceled) setPicked(result.assets.map(a => a.uri))
  }

  function buy() {
    Alert.alert('JUDASHOP', 'La compra estará disponible cuando conectemos pagos y protección al comprador.')
  }

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="dark" />
      <View style={styles.app}>
        {tab === 'Inicio' && (
          <ScrollView contentContainerStyle={styles.scroll}>
            <View style={styles.header}>
              <View>
                <Text style={styles.logo}>JUDASHOP</Text>
                <Text style={styles.subtitle}>Compra. Vende. En cualquier lugar.</Text>
              </View>
              <Text style={styles.globe}>🌍</Text>
            </View>

            <View style={styles.searchBox}>
              <Text style={{fontSize: 18}}>⌕</Text>
              <TextInput
                value={search}
                onChangeText={setSearch}
                placeholder="Buscar lo que quieras..."
                placeholderTextColor="#999"
                style={styles.searchInput}
              />
            </View>

            <View style={styles.categoryRow}>
              {['👗 Moda','👟 Zapatillas','👜 Bolsos','📱 Tech'].map(x =>
                <Pressable key={x} style={styles.cat}><Text>{x}</Text></Pressable>
              )}
            </View>

            <SectionTitle title="Tendencias" />
            <ProductGrid products={filtered} onBuy={buy} />

            <SectionTitle title="De todo el mundo" />
            <View style={styles.worldCard}>
              <Text style={styles.worldEmoji}>🌍</Text>
              <View style={{flex:1}}>
                <Text style={styles.worldTitle}>Compra y vende internacionalmente</Text>
                <Text style={styles.muted}>Monedas, envíos y seguimiento preparados para crecer.</Text>
              </View>
            </View>
          </ScrollView>
        )}

        {tab === 'Buscar' && (
          <ScrollView contentContainerStyle={styles.scroll}>
            <Text style={styles.pageTitle}>Buscar</Text>
            <View style={styles.searchBox}>
              <Text style={{fontSize:18}}>⌕</Text>
              <TextInput value={search} onChangeText={setSearch} placeholder="¿Qué buscas?" style={styles.searchInput}/>
            </View>
            <ProductGrid products={filtered} onBuy={buy} />
          </ScrollView>
        )}

        {tab === 'Vender' && (
          <ScrollView contentContainerStyle={styles.scroll}>
            <Text style={styles.pageTitle}>Vender</Text>
            <Text style={styles.bigIntro}>Crea tu anuncio en menos de un minuto.</Text>
            <Pressable style={styles.aiButton} onPress={pickImages}>
              <Text style={styles.aiIcon}>✨</Text>
              <View style={{flex:1}}>
                <Text style={styles.aiTitle}>Crear anuncio con IA</Text>
                <Text style={styles.aiSub}>Haz fotos y JUDASHOP prepara título, descripción y precio sugerido.</Text>
              </View>
              <Text style={styles.arrow}>›</Text>
            </Pressable>
            <Pressable style={styles.photoBox} onPress={pickImages}>
              <Text style={{fontSize:36}}>＋</Text>
              <Text style={{fontWeight:'700'}}>Añadir fotos</Text>
              <Text style={styles.muted}>Hasta 8 fotos</Text>
            </Pressable>
            <View style={styles.photoRow}>
              {picked.map((uri, i) => <Image key={i} source={{uri}} style={styles.picked}/>)}
            </View>
            <Text style={styles.label}>Título</Text>
            <TextInput placeholder="Ej. Vestido Zara negro" style={styles.input}/>
            <Text style={styles.label}>Precio</Text>
            <TextInput placeholder="0,00 €" keyboardType="decimal-pad" style={styles.input}/>
            <Pressable style={styles.sellButton} onPress={() => Alert.alert('JUDASHOP','Anuncio preparado. La publicación real se conectará a Supabase en el siguiente paso.')}>
              <Text style={styles.sellText}>Publicar anuncio</Text>
            </Pressable>
          </ScrollView>
        )}

        {tab === 'Mensajes' && (
          <ScrollView contentContainerStyle={styles.scroll}>
            <Text style={styles.pageTitle}>Mensajes</Text>
            <View style={styles.empty}>
              <Text style={{fontSize:45}}>💬</Text>
              <Text style={styles.emptyTitle}>Tus conversaciones aparecerán aquí</Text>
              <Text style={styles.muted}>Habla con compradores y vendedores antes de comprar.</Text>
            </View>
          </ScrollView>
        )}

        {tab === 'Perfil' && (
          <ScrollView contentContainerStyle={styles.scroll}>
            <Text style={styles.pageTitle}>Mi perfil</Text>
            <View style={styles.profile}>
              <View style={styles.avatar}><Text style={{fontSize:30}}>👤</Text></View>
              <Text style={styles.profileName}>{session?.user?.email || 'Tu perfil JUDASHOP'}</Text>
              <Text style={styles.muted}>Compra y vende en todo el mundo 🌍</Text>
            </View>
            {['Mis anuncios','Mis compras','Mis ventas','Favoritos','Valoraciones','Configuración'].map(x =>
              <Pressable key={x} style={styles.menu}><Text style={{fontSize:16,fontWeight:'600'}}>{x}</Text><Text>›</Text></Pressable>
            )}
          </ScrollView>
        )}

        <View style={styles.nav}>
          {[
            ['⌂','Inicio'],['⌕','Buscar'],['＋','Vender'],['💬','Mensajes'],['◯','Perfil']
          ].map(([icon,name]) =>
            <Pressable key={name} onPress={() => setTab(name)} style={styles.navItem}>
              <Text style={[styles.navIcon, tab===name && {color:PINK}]}>{icon}</Text>
              <Text style={[styles.navText, tab===name && {color:PINK,fontWeight:'800'}]}>{name}</Text>
            </Pressable>
          )}
        </View>
      </View>
    </SafeAreaView>
  )
}

function SectionTitle({title}:{title:string}) {
  return <View style={styles.sectionHead}><Text style={styles.sectionTitle}>{title}</Text><Text style={{color:PINK,fontWeight:'700'}}>Ver todo</Text></View>
}

function ProductGrid({products,onBuy}:{products:any[],onBuy:()=>void}) {
  return <View style={styles.grid}>
    {products.map(p =>
      <Pressable key={p.id} style={styles.card} onPress={onBuy}>
        <Image source={{uri:p.img}} style={styles.productImg}/>
        <View style={styles.cardBody}>
          <Text style={styles.cardTitle} numberOfLines={1}>{p.title}</Text>
          <Text style={styles.cardPrice}>{p.price}</Text>
          <Text style={styles.muted}>{p.cat} · Envío disponible</Text>
        </View>
      </Pressable>
    )}
  </View>
}

const styles = StyleSheet.create({
  safe:{flex:1,backgroundColor:BG},
  app:{flex:1,backgroundColor:BG},
  scroll:{padding:18,paddingBottom:110},
  header:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',marginBottom:16},
  logo:{fontSize:28,fontWeight:'900',letterSpacing:-1,color:PINK},
  subtitle:{fontSize:12,color:'#777',marginTop:2},
  globe:{fontSize:28},
  searchBox:{height:50,backgroundColor:'#fff',borderRadius:16,flexDirection:'row',alignItems:'center',paddingHorizontal:15,marginBottom:15,borderWidth:1,borderColor:'#f0e6eb'},
  searchInput:{flex:1,fontSize:15,marginLeft:8},
  categoryRow:{flexDirection:'row',gap:8,marginBottom:22},
  cat:{backgroundColor:'#fff',paddingHorizontal:11,paddingVertical:10,borderRadius:14},
  sectionHead:{flexDirection:'row',justifyContent:'space-between',alignItems:'center',marginBottom:12},
  sectionTitle:{fontSize:21,fontWeight:'900',color:dark},
  grid:{flexDirection:'row',flexWrap:'wrap',justifyContent:'space-between'},
  card:{width:'48%',backgroundColor:'#fff',borderRadius:18,overflow:'hidden',marginBottom:14},
  productImg:{width:'100%',height:160},
  cardBody:{padding:10},
  cardTitle:{fontWeight:'800',fontSize:14},
  cardPrice:{fontWeight:'900',fontSize:17,marginTop:4},
  muted:{color:'#777',fontSize:12,lineHeight:17},
  worldCard:{backgroundColor:'#fff',borderRadius:20,padding:16,flexDirection:'row',gap:12,alignItems:'center',marginTop:2},
  worldEmoji:{fontSize:35},
  worldTitle:{fontSize:16,fontWeight:'900',marginBottom:4},
  nav:{position:'absolute',bottom:0,left:0,right:0,height:78,backgroundColor:'#fff',borderTopWidth:1,borderTopColor:'#eee',flexDirection:'row',justifyContent:'space-around',paddingTop:8},
  navItem:{alignItems:'center',width:'20%'},
  navIcon:{fontSize:23,color:'#555',height:30},
  navText:{fontSize:11,color:'#555'},
  pageTitle:{fontSize:30,fontWeight:'900',marginBottom:18,color:dark},
  bigIntro:{fontSize:22,fontWeight:'800',lineHeight:29,marginBottom:16},
  aiButton:{backgroundColor:'#ffe8f2',borderRadius:22,padding:17,flexDirection:'row',alignItems:'center',gap:12},
  aiIcon:{fontSize:30},
  aiTitle:{fontSize:17,fontWeight:'900'},
  aiSub:{fontSize:12,color:'#777',marginTop:4,lineHeight:17},
  arrow:{fontSize:28,color:PINK},
  photoBox:{height:180,borderWidth:2,borderStyle:'dashed',borderColor:'#ffc0d8',borderRadius:20,marginTop:16,alignItems:'center',justifyContent:'center',backgroundColor:'#fff'},
  photoRow:{flexDirection:'row',flexWrap:'wrap',gap:8,marginTop:10},
  picked:{width:75,height:75,borderRadius:12},
  label:{fontWeight:'800',marginTop:18,marginBottom:7},
  input:{backgroundColor:'#fff',borderRadius:14,padding:14,fontSize:16},
  sellButton:{backgroundColor:PINK,borderRadius:18,padding:16,alignItems:'center',marginTop:22},
  sellText:{color:'#fff',fontWeight:'900',fontSize:16},
  empty:{backgroundColor:'#fff',borderRadius:22,padding:30,alignItems:'center',marginTop:20},
  emptyTitle:{fontSize:18,fontWeight:'900',marginTop:12,textAlign:'center',marginBottom:5},
  profile:{backgroundColor:'#fff',borderRadius:22,padding:24,alignItems:'center',marginBottom:14},
  avatar:{width:80,height:80,borderRadius:40,backgroundColor:'#ffe8f2',alignItems:'center',justifyContent:'center',marginBottom:10},
  profileName:{fontSize:18,fontWeight:'900',marginBottom:4},
  menu:{backgroundColor:'#fff,borderRadius:16,padding:17,flexDirection:'row',justifyContent:'space-between',marginBottom:8'}
})
